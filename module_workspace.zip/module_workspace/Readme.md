# 2020-07-29 RUDA LEE
# SK_infosec - Cloud AI 전문가 과정 교육 

# host='localhost' url 정보
# user='aiadmin'
# password='password'
# db='module_db'
# docker에서 mysql 실행. port 3306
# 포트 포워딩 - 이름 : mysql, 호스트IP : 127.0.0.1, 게스트 포트 : 3306

## 테이블 선언은 아래와 같이 수행 됨.
use module_db; 
 
CREATE TABLE member_ (
 	email varchar(50) PRIMARY KEY,
 	name varchar(30),
 	phone_number varchar(20),
 	birthday varchar(20)
 );
ALTER TABLE member_ convert to character set UTF8;

CREATE TABLE club_ (
 	clubID varchar(20) PRIMARY KEY,
 	name varchar(50),
 	phone_number varchar(20),
 	foundation_date varchar(20),
 	address varchar(50)
 );
ALTER TABLE club_ convert to character set UTF8;
 
CREATE TABLE membership_ (
	membershipID varchar(20) PRIMARY KEY,
 	clubID varchar(20),
 	member_email varchar(50),
 	join_date varchar(20),
 	role_in_club varchar(20)
 );
ALTER TABLE membership_ convert to character set UTF8;